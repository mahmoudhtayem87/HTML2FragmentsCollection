module.exports = require('generator-liferay-fragments').getBundlerConfig();
